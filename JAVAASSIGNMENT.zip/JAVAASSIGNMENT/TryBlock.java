package assignment;

public class TryBlock {
	public static void main(String[] args) {
        int dividend = 30;
	int divisor = 2;
try {
	int result = divide(dividend,divisor);
	System.out.println(result);
 }
catch (ArithmeticException e) {
	System.out.println("an arithmetic exception");
 }
 }
public static int divide(int dividend, int divisor) {
     if (divisor ==0) {
		throw new ArithmeticException("cannot divide by zero");
	}
	return dividend/divisor;
}
}
