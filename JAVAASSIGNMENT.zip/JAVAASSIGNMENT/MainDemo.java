package assignment;

public class MainDemo extends InheritanceDemo{
	char ch ='j';
	public static void wish() {
		System.out.println("wish is in sub-class");
	}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			MainDemo md = new MainDemo();
			System.out.println(md.i);
			System.out.println(md.s);
			System.out.println(md.ch);
			md.display();
			md.wish();

		}
}
