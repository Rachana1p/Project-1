package assignment;

public class MultipleCatchBlocks {
	 public static void main(String[] args) {
		        
	          try {
			int [] numbers = {1,2,3};
			int result = numbers[3] /0;
	            }
		   catch(ArithmeticException e)
	             {
			System.out.println("ArithmeticException caught : ");
			}
		   catch(ArrayIndexOutOfBoundsException e)
			{
			System.out.println("Arrayindexoutofboundsexception occured ");

	              }
		    catch(Exception e)
	               {
	                  System.out.println("program continues after exception handling. ");
	               }
	}
}
