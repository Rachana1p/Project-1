package assignment;

public class B extends A
{
	public void methodB() {
		System.out.println("display is in sub class");
	}	
	public static void main(String[] args) {
		B b1=new B();
		b1.methodA();
		b1.methodB();
	}
}
