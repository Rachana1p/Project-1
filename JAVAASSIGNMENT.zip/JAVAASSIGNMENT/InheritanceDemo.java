package assignment;

public class InheritanceDemo {
	int i=10;
	String s ="java";
	public static void display() {
		System.out.println("display is in super class");
	}
}
 
