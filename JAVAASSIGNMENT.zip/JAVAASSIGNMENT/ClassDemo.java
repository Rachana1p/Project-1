package assignment;

public class ClassDemo {
	int i;
	double d;
	ClassDemo(int i,double d){
		this.i=i;
		this.d=d;
	}
	public static void main(String[] args) {
		ClassDemo c1=new ClassDemo(3,5.1);
		System.out.println(c1.i+"-----"+c1.d);
		ClassDemo c2=new ClassDemo(4,6.1);
		System.out.println(c2.i+"------"+c2.d);
		
	}
}
