package assignment;

public class A {
public void methodA() {
	System.out.println("display is in super class");
}
}
