package assignment;

import java.util.ArrayList;

public class GeometryCalculator {
	public static void main(String[] args) {
	     try {
	         // Creating objects
	         Rectangle rectangle = new Rectangle(5, 10);
	         Circle circle = new Circle(3);

	         // Adding objects to ArrayList
	         ArrayList<GeometricShape> shapes = new ArrayList<>();
	         shapes.add(rectangle);
	         shapes.add(circle);

	         // Displaying areas using loop
	         for (GeometricShape shape : shapes) {
	             shape.displayArea();
	         }
	     } catch (Exception e) {
	         System.out.println("An error occurred: " + e.getMessage());
	     } finally {
	         System.out.println("Program execution completed.");
	     }
	 }
	}


