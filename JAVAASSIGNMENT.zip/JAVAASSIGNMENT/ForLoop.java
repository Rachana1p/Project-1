package assignment;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int x=2;x<=4;x++) {
			System.out.println("value of x:"+ x);
		}
		int arr[]= {10,20,30,40,50};
		for(int i:arr) {
			System.out.println(i);
		}
	}

}
